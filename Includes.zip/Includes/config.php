<?php
	/**
 * Entité des utilisateurs
 * @author Théo Bance
*
 */

define('SECRET_KEY', 'N0u5S0mm35L35D3v3l0pp3ur20232025');